package com.example.crypto_currency_tracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.DrawableContainer;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Dashboardpolicies extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboardpolicies);

        TextView mreferencepolicies = (TextView) findViewById(R.id.crypto_policies);
        String policies = "There have been big questions about what role of blockchain, cryptocurrencies, digital assets, tokens and tokenomics play in society. Cryptocurrencies and blockchain – the technology behind cryptocurrencies – have become a global phenomenon. Since the creation of Bitcoin, the world’s most well known cryptocurrency, the research on cryptocurrency and blockchain has become widespread and has generated an enormous amount of concerns among various countries’ governments, central banks and regulators. The most common concern is how to regulate cryptocurrencies. Because of its specific distributed and disintermediated nature, current rules cannot be applied to them. In this paper, we are going to go through some of the most prominent trends while assessing the complexity behind blockchain and cryptocurrency regulation.\n" +
                "\n" +
                "Global economists such as Nouriel Roubini continue with his passionate assertion that 99% of cryptocurrencies are worth ZERO. He also states that it is fintech, and not blockchain, that will bring innovation to the banking system. Other major personalities such as the ex Governor of the Bank of England and heads of major investments banks have publicly attacked crypto currencies, but most of them have already initiated studies and deployment of the technology.\n" +
                "\n" +
                "The president of the European Central Bank (ECB), Christine Lagarde, has said central banks and financial bodies should protect consumers but be open to innovations such as cryptocurrencies. Lagarde, who was previously the head of the International Monetary Fund, told the Economic and Monetary Affairs Committee of the European Parliament that central banks and financial regulators should embrace the opportunities presented by change.\n" +
                "\n" +
                "Christine Lagarde via an IMF news release, said: ”In the case of new technologies – including digital currencies – that means being alert to risks in terms of financial stability, privacy or criminal activities, and ensuring appropriate regulation is in place to steer technology towards the public good. But it also means recognising the wider social benefits from innovation and allowing them space to develop.” Lagarde claimed that regulation of cryptocurrencies is “inevitable” and necessary on an international level. She also said that blockchain innovators are “shaking the traditional financial world” and having a clear impact on incumbent players.\n" +
                "\n" +
                "Digital assets, majorly cryptocurrencies, have been around for decades. The first cryptocurrency Bitcoin was launched in 2009 and yet government entities and financial institutions have largely been reluctant to adopt it. A huge part of this reluctance can be traced to its regulatory landscape which is still developing. However, it is changing rapidly. In January 2021, the Office of the Comptroller of the Currency  granted a national trust bank charter to South Dakota-based chartered trust company, making it the very first federally chartered bank for digital assets in the United States. Moreover, it has also allowed the bank to collaborate with other traditional financial institutions to provide cryptocurrencies to customers.\n" +
                "\n" +
                "Moreover, The Securities and Exchange Commission took a similar step by issuing a statement in December 2020. The statement clarified how brokers and dealers must operate when they’re acting as custodians of cryptocurrencies and digital asset securities to avoid enforcement action. A better regulatory framework will help in making traditional insurers more ready and willing to provide cryptocurrency insurance. However, at this point of time where the regulatory environment continues to evolve, more education is needed.\n";

        mreferencepolicies.setText(policies);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.crypto_policies);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.crypto_policies:
                        return true;
                    case R.id.home:
                        startActivity(new Intent(getApplicationContext() , MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.graphs:
                        startActivity(new Intent(getApplicationContext() , GraphWeb.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.about:
                        startActivity(new Intent(getApplicationContext() , about.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });
    }
}