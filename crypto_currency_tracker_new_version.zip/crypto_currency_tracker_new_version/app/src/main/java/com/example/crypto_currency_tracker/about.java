package com.example.crypto_currency_tracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class about extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about2);

        TextView mreferenceabout = (TextView) findViewById(R.id.about);
        String about = "No investment is without risk, but investing in bitcoin carries different risks and responsibilities compared to traditional investments of stocks, bonds and funds. And the bitcoin investor plays a big role in keeping their bitcoin safe.\n" +
                "\n" +
                "Here are some key things to know:\n" +
                "The value of bitcoin can be extremely volatile\n" +
                "\n" +
                "Many investors piled into bitcoin after it broke the $20,000 barrier in December 2020 and continued its bull run into April, when the spot price surged above $64,000. But in the months after, the price began a long decline, with the spot price falling below $32,000 by early June.\n" +
                "\n" +
                "Longtime investors in cryptocurrency had seen this before. Bitcoin reached its previous record high in December 2017, when the spot price came near $20,000, and one year later the spot price was below $3,400.\n" +
                "\n" +
                "So when investing in bitcoin, understand that the value can drop quickly — and may take years to regain previous highs.\n" +
                "\n" +
                "When you’re buying Ethereum, technically you’re converting your U.S. dollars into “ether,” or ETH, which is the currency of the Ethereum blockchain. In order to use the Ethereum blockchain (which includes sending ETH as a form of payment or using an application that runs on Ethereum), you’ll need ETH to pay a transaction fee.\n" +
                "\n" +
                "So what can you do on the Ethereum blockchain? While the technology is still very young — and frankly, untested in many ways — people can use Ethereum to run “decentralized applications,” or dapps. Dapps essentially cut out the middleman in industries where middlemen have for the most part always existed, relying instead on “smart contracts” that run on Ethereum. To use these applications, you’ll need ETH to pay for the cost of “gas” — a measurement of how much computing power is needed to run the application. Examples of dapps include:\n" +
                "\n" +
                "    Direct peer lending that earns interest.\n" +
                "\n" +
                "    Insurance without the insurance company.\n" +
                "\n" +
                "    Payments without the payment processing company.\n" +
                "\n" +
                "    Music streaming in which the money goes directly to the artist, not a streaming platform or record label.\n" +
                "\n" +
                "    Art auctions without an auctioneer.\n" +
                "\n" +
                "    Marketplaces for nonfungible tokens, or NFTs.\n" +
                "\n" +
                "    Online gaming.\n" +
                "\n" +
                "    Code collaboration without a central server.\n" +
                "\n" +
                "This is all extremely complex, so if you’re confused, don’t worry. That’s normal. But put very simply, when you’re investing in Ethereum, you’re betting that people are going to keep adopting and using new Ethereum-based technologies like the ones listed above, which could possibly drive demand for ETH — and its market value — higher.";



        mreferenceabout.setText(about);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.about);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.crypto_policies:
                        startActivity(new Intent(getApplicationContext() , Dashboardpolicies.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.home:
                        startActivity(new Intent(getApplicationContext() , MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.graphs:
                        startActivity(new Intent(getApplicationContext() , GraphWeb.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.about:
                        return true;
                }
                return false;
            }
        });
    }
}